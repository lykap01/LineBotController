/*
  Autonomous Line-Following Robot
  with Bluetooth Smartphone Control and Ultrasonic-Based Obstacle Avoidance

  Board  : Arduino Nano V3
  Driver : TB6612FNG
  Sensors: 5-way IR line sensor, HC-SR04 ultrasonic
  BT     : HC-05 (SoftwareSerial on D2/D3, 9600 baud)

  Wiring (corrected schematic):
    IR S1..S5  -> A0..A4        (S1 = far left, S5 = far right)
    HC-05 TXD  -> D2            HC-05 RXD <- D3 through 1k/2k divider
    TB6612 STBY-> D4
    PWMA -> D5   AIN1 -> D12   AIN2 -> D11   (left motor,  AO1/AO2)
    PWMB -> D6   BIN1 -> D10   BIN2 -> D9    (right motor, BO1/BO2)
    HC-SR04 TRIG -> D7   ECHO -> D8
    Status LED -> D13 (through 220 ohm to GND)

  Bluetooth commands (send single characters):
    A = start AUTO line following
    M = MANUAL mode (motors stop)
    X = stop everything (works in any mode)
    F / B / L / R = forward / back / left / right (manual)
    G / I = forward-left / forward-right
    H / J = back-left / back-right
    S = stop (manual only; ignored in AUTO because many RC apps spam 'S')
    0..9, Q = manual speed (Q = max)
    + / - = raise / lower AUTO line-following speed
    D = report distance,  ? = report status

  Status LED:
    solid ON   = AUTO mode, following the line
    slow blink = MANUAL mode
    fast blink = obstacle detected / avoiding
*/

#include <SoftwareSerial.h>

// ===================== PINS =====================
const uint8_t IR_PINS[5] = {A0, A1, A2, A3, A4};
const uint8_t BT_RX = 2;   // Nano receives on D2  (from HC-05 TXD)
const uint8_t BT_TX = 3;   // Nano transmits on D3 (to HC-05 RXD via divider)
const uint8_t STBY  = 4;
const uint8_t PWMA  = 5;   // left motor speed  (PWM)
const uint8_t PWMB  = 6;   // right motor speed (PWM)
const uint8_t TRIG  = 7;
const uint8_t ECHO  = 8;
const uint8_t BIN2  = 9;
const uint8_t BIN1  = 10;
const uint8_t AIN2  = 11;
const uint8_t AIN1  = 12;
const uint8_t LED   = 13;

// ===================== SETTINGS (tune these) =====================
// Most TCRT5000-style modules output LOW over a black line.
// If the robot reacts to the white floor instead of the line, set this to false.
const bool LINE_IS_LOW = true;

// If a wheel spins backward when it should go forward, flip its flag.
const bool LEFT_MOTOR_REVERSED  = false;
const bool RIGHT_MOTOR_REVERSED = false;

const int MAX_SPEED    = 220;  // cap: 2S LiPo is 8.4V when full, motors are 6V
int       baseSpeed    = 150;  // AUTO cruising speed (0-255)
int       manualSpeed  = 170;  // MANUAL speed (0-255)
const int SEARCH_SPEED = 120;  // pivot speed when the line is lost

// PD controller. Raise Kp if it drifts off curves; raise Kd if it wobbles.
float Kp = 35.0;
float Kd = 20.0;
// Sensor weights, left to right. If the robot steers AWAY from the line,
// reverse these signs: {4, 2, 0, -2, -4}.
const int WEIGHTS[5] = {-4, -2, 0, 2, 4};

// Obstacle handling
const int  OBSTACLE_CM        = 15;    // stop/avoid when closer than this
const bool GO_AROUND_OBSTACLE = true;  // false = stop and wait until clear
const int  AVOID_SPEED        = 150;

// Go-around timings in ms. Tune on your floor so each turn is about 90 degrees.
const unsigned long T_PAUSE     = 300;
const unsigned long T_TURN      = 350;   // ~90 degree pivot
const unsigned long T_SIDE      = 500;   // move sideways away from obstacle
const unsigned long T_PASS      = 800;   // drive past the obstacle
const unsigned long T_SEEK_MAX  = 3000;  // give up if line not found

// ===================== STATE =====================
SoftwareSerial bt(BT_RX, BT_TX);

enum Mode { MODE_MANUAL, MODE_AUTO };
Mode mode = MODE_MANUAL;            // start stopped for safety; send 'A' to run

enum AvoidState { AV_NONE, AV_PAUSE, AV_WAIT, AV_TURN_OUT, AV_SIDE,
                  AV_TURN_BACK, AV_PASS, AV_TURN_IN, AV_SEEK };
AvoidState avoid = AV_NONE;
unsigned long avoidStart = 0;

char  manualCmd  = 'S';
float lastError  = 0;

int  distanceCm    = 999;
uint8_t obstacleHits = 0;
unsigned long lastPing = 0;

// ===================== HELPERS =====================
void say(const __FlashStringHelper *msg) {
  bt.println(msg);
  Serial.println(msg);
}

void driveMotor(uint8_t in1, uint8_t in2, uint8_t pwm, int speed, bool reversed) {
  if (reversed) speed = -speed;
  speed = constrain(speed, -MAX_SPEED, MAX_SPEED);
  if (speed > 0) {
    digitalWrite(in1, HIGH); digitalWrite(in2, LOW);
  } else if (speed < 0) {
    digitalWrite(in1, LOW);  digitalWrite(in2, HIGH);
  } else {
    digitalWrite(in1, LOW);  digitalWrite(in2, LOW);
  }
  analogWrite(pwm, abs(speed));
}

void setMotors(int left, int right) {
  driveMotor(AIN1, AIN2, PWMA, left,  LEFT_MOTOR_REVERSED);
  driveMotor(BIN1, BIN2, PWMB, right, RIGHT_MOTOR_REVERSED);
}

void stopMotors() { setMotors(0, 0); }

// Returns how many sensors see the line; fills s[] with true/false.
uint8_t readLine(bool s[5]) {
  uint8_t count = 0;
  for (uint8_t i = 0; i < 5; i++) {
    bool raw = digitalRead(IR_PINS[i]);
    s[i] = LINE_IS_LOW ? !raw : raw;
    if (s[i]) count++;
  }
  return count;
}

int readDistanceCm() {
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  unsigned long us = pulseIn(ECHO, HIGH, 25000UL);  // ~4 m timeout
  if (us == 0) return 999;                          // no echo = nothing close
  return us / 58;
}

void setAvoid(AvoidState s) {
  avoid = s;
  avoidStart = millis();
}

void goManual() {
  mode = MODE_MANUAL;
  avoid = AV_NONE;
  manualCmd = 'S';
  stopMotors();
}

// ===================== LINE FOLLOWING =====================
void followLine() {
  bool s[5];
  uint8_t n = readLine(s);

  if (n == 0) {                       // line lost: pivot toward last side seen
    if (lastError < 0) setMotors(-SEARCH_SPEED, SEARCH_SPEED);
    else               setMotors(SEARCH_SPEED, -SEARCH_SPEED);
    return;
  }

  if (n == 5) {                       // junction / thick mark: go straight
    setMotors(baseSpeed, baseSpeed);
    return;
  }

  int sum = 0;
  for (uint8_t i = 0; i < 5; i++) if (s[i]) sum += WEIGHTS[i];
  float error = (float)sum / n;       // -4 (line far left) .. +4 (far right)

  float correction = Kp * error + Kd * (error - lastError);
  lastError = error;

  setMotors((int)(baseSpeed + correction), (int)(baseSpeed - correction));
}

// ===================== OBSTACLE AVOIDANCE =====================
void runAvoid(bool obstacle) {
  unsigned long t = millis() - avoidStart;

  switch (avoid) {
    case AV_PAUSE:
      stopMotors();
      if (t > T_PAUSE) setAvoid(GO_AROUND_OBSTACLE ? AV_TURN_OUT : AV_WAIT);
      break;

    case AV_WAIT:                      // stop-and-wait mode
      stopMotors();
      if (!obstacle) { avoid = AV_NONE; say(F("Path clear")); }
      break;

    case AV_TURN_OUT:                  // pivot right
      setMotors(AVOID_SPEED, -AVOID_SPEED);
      if (t > T_TURN) setAvoid(AV_SIDE);
      break;

    case AV_SIDE:                      // move away from the line
      setMotors(AVOID_SPEED, AVOID_SPEED);
      if (t > T_SIDE) setAvoid(AV_TURN_BACK);
      break;

    case AV_TURN_BACK:                 // pivot left, now parallel to the line
      setMotors(-AVOID_SPEED, AVOID_SPEED);
      if (t > T_TURN) setAvoid(AV_PASS);
      break;

    case AV_PASS:                      // drive past the obstacle
      setMotors(AVOID_SPEED, AVOID_SPEED);
      if (t > T_PASS) setAvoid(AV_TURN_IN);
      break;

    case AV_TURN_IN:                   // pivot left, back toward the line
      setMotors(-AVOID_SPEED, AVOID_SPEED);
      if (t > T_TURN) setAvoid(AV_SEEK);
      break;

    case AV_SEEK: {                    // creep forward until the line is found
      bool s[5];
      setMotors(AVOID_SPEED - 30, AVOID_SPEED - 30);
      if (readLine(s) > 0) {
        avoid = AV_NONE;
        lastError = 4;                 // line is ahead; bias the turn right to rejoin
        say(F("Back on line"));
      } else if (t > T_SEEK_MAX) {
        goManual();
        say(F("Line not found - switched to MANUAL"));
      }
      break;
    }

    default:
      avoid = AV_NONE;
      break;
  }
}

// ===================== MANUAL DRIVE =====================
void runManual(bool obstacle) {
  int sp = manualSpeed;
  switch (manualCmd) {
    case 'F': if (obstacle) stopMotors(); else setMotors(sp, sp);     break;
    case 'G': if (obstacle) stopMotors(); else setMotors(sp / 2, sp); break;
    case 'I': if (obstacle) stopMotors(); else setMotors(sp, sp / 2); break;
    case 'B': setMotors(-sp, -sp);     break;
    case 'H': setMotors(-sp / 2, -sp); break;
    case 'J': setMotors(-sp, -sp / 2); break;
    case 'L': setMotors(-sp, sp);      break;
    case 'R': setMotors(sp, -sp);      break;
    default:  stopMotors();            break;
  }
}

// ===================== BLUETOOTH =====================
void reportStatus() {
  bt.print(F("Mode: "));    bt.println(mode == MODE_AUTO ? F("AUTO") : F("MANUAL"));
  bt.print(F("Auto speed: ")); bt.println(baseSpeed);
  bt.print(F("Manual speed: ")); bt.println(manualSpeed);
  bt.print(F("Distance: ")); bt.print(distanceCm); bt.println(F(" cm"));
}

void handleBluetooth() {
  while (bt.available()) {
    char c = toupper(bt.read());
    if (c == '\r' || c == '\n' || c == ' ') continue;

    switch (c) {
      case 'A':
        mode = MODE_AUTO; avoid = AV_NONE; lastError = 0;
        say(F("Mode: AUTO"));
        break;

      case 'M':
        goManual();
        say(F("Mode: MANUAL"));
        break;

      case 'X':
        goManual();
        say(F("STOP"));
        break;

      case 'S':
        if (mode == MODE_MANUAL) { manualCmd = 'S'; stopMotors(); }
        break;

      case 'F': case 'B': case 'L': case 'R':
      case 'G': case 'I': case 'H': case 'J':
        if (mode == MODE_AUTO) { mode = MODE_MANUAL; avoid = AV_NONE; say(F("Mode: MANUAL")); }
        manualCmd = c;
        break;

      case 'Q':
        manualSpeed = MAX_SPEED;
        break;

      case '+':
        baseSpeed = min(baseSpeed + 10, MAX_SPEED);
        bt.print(F("Auto speed: ")); bt.println(baseSpeed);
        break;

      case '-':
        baseSpeed = max(baseSpeed - 10, 60);
        bt.print(F("Auto speed: ")); bt.println(baseSpeed);
        break;

      case 'D':
        bt.print(F("Distance: ")); bt.print(distanceCm); bt.println(F(" cm"));
        break;

      case '?':
        reportStatus();
        break;

      default:
        if (c >= '0' && c <= '9') manualSpeed = map(c - '0', 0, 9, 60, MAX_SPEED);
        break;
    }
  }
}

// ===================== LED =====================
void updateLed(bool obstacle) {
  unsigned long now = millis();
  if (avoid != AV_NONE || obstacle) digitalWrite(LED, (now / 100) % 2);  // fast blink
  else if (mode == MODE_AUTO)       digitalWrite(LED, HIGH);              // solid
  else                              digitalWrite(LED, (now / 500) % 2);  // slow blink
}

// ===================== SETUP / LOOP =====================
void setup() {
  for (uint8_t i = 0; i < 5; i++) pinMode(IR_PINS[i], INPUT);

  pinMode(STBY, OUTPUT);
  pinMode(PWMA, OUTPUT); pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(PWMB, OUTPUT); pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT);
  pinMode(LED, OUTPUT);

  digitalWrite(TRIG, LOW);
  digitalWrite(STBY, HIGH);   // enable the TB6612
  stopMotors();

  Serial.begin(9600);         // USB debug
  bt.begin(9600);             // HC-05 default baud

  say(F("Robot ready. Send A = auto, M = manual, X = stop, ? = status"));
}

void loop() {
  handleBluetooth();

  // Ultrasonic reading every 60 ms; needs 2 close readings in a row to count
  unsigned long now = millis();
  if (now - lastPing >= 60) {
    lastPing = now;
    distanceCm = readDistanceCm();
    if (distanceCm < OBSTACLE_CM) { if (obstacleHits < 255) obstacleHits++; }
    else obstacleHits = 0;
  }
  bool obstacle = obstacleHits >= 2;

  if (mode == MODE_AUTO) {
    if (avoid != AV_NONE) {
      runAvoid(obstacle);
    } else if (obstacle) {
      stopMotors();
      say(F("Obstacle detected"));
      setAvoid(AV_PAUSE);
    } else {
      followLine();
    }
  } else {
    runManual(obstacle);
  }

  updateLed(obstacle);
}
