package com.linebot.pilot;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * LineBot Pilot: full-screen WebView UI (assets/index.html) + classic Bluetooth
 * SPP (RFCOMM) link to an HC-05 / HC-06 module at the Arduino side.
 *
 * JS -> native : window.AndroidBT.*  (see Bridge below)
 * native -> JS : window.__native({type: ..., ...})
 */
public class MainActivity extends Activity {

    /** Standard Serial Port Profile UUID used by HC-05 / HC-06. */
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int REQ_PERMS = 41;
    private static final int REQ_ENABLE = 42;

    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private BluetoothAdapter adapter;
    private volatile BluetoothSocket socket;
    private volatile OutputStream out;
    private volatile boolean closing = false;
    private volatile String connectedName = "";

    // ------------------------------------------------------------------ lifecycle

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm != null ? bm.getAdapter() : null;

        web = new WebView(this);
        web.setBackgroundColor(0xFF05040D);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(true);
        ws.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBT");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Back button closes an open panel in the page first; otherwise leaves the app. */
    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) {
            leave();
            return;
        }
        web.evaluateJavascript("(window.__back && window.__back()) === true", v -> {
            if (!"true".equals(v)) leave();
        });
    }

    @SuppressWarnings("deprecation")
    private void leave() {
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Safety: stop manual driving when the app goes to the background.
        if (out != null) writeAsync("S");
    }

    @Override
    protected void onDestroy() {
        closeSocket();
        io.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ permissions / enable

    private boolean hasConnectPermission() {
        if (Build.VERSION.SDK_INT < 31) return true;
        return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    /** Make sure we have permission and Bluetooth is on, then tell the page it can list devices. */
    private void prepare() {
        if (adapter == null) {
            emit(event("error").putQuiet("message", "This phone has no Bluetooth."));
            return;
        }
        if (!hasConnectPermission()) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_PERMS);
            return;
        }
        if (!adapter.isEnabled()) {
            try {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE);
            } catch (SecurityException e) {
                emit(event("error").putQuiet("message", "Turn on Bluetooth, then tap Connect again."));
            }
            return;
        }
        emit(event("ready"));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            prepare();
        } else {
            emit(event("error").putQuiet("message",
                    "Bluetooth permission is needed. Allow \"Nearby devices\" for LineBot Pilot in Settings > Apps."));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_ENABLE) return;
        if (adapter != null && adapter.isEnabled()) emit(event("ready"));
        else emit(event("error").putQuiet("message", "Bluetooth is off. Turn it on to connect."));
    }

    // ------------------------------------------------------------------ Bluetooth link

    @SuppressLint("MissingPermission")
    private JSONArray pairedDevices() {
        JSONArray arr = new JSONArray();
        if (adapter == null || !hasConnectPermission()) return arr;
        try {
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            if (bonded == null) return arr;
            for (BluetoothDevice d : bonded) {
                JSONObject o = new JSONObject();
                String name = d.getName();
                o.put("name", name == null ? "(no name)" : name);
                o.put("address", d.getAddress());
                arr.put(o);
            }
        } catch (SecurityException | JSONException ignored) {
        }
        return arr;
    }

    @SuppressLint("MissingPermission")
    private void doConnect(String address) {
        closeSocket();
        closing = false;
        emit(event("status").putQuiet("state", "connecting"));
        BluetoothDevice dev;
        try {
            dev = adapter.getRemoteDevice(address);
        } catch (IllegalArgumentException e) {
            emit(event("failed").putQuiet("message", "Bad device address."));
            return;
        }
        try {
            adapter.cancelDiscovery();
        } catch (SecurityException ignored) {
        }

        BluetoothSocket s = null;
        String why = "";
        // 1) Standard secure SPP socket (works for most HC-05 modules).
        try {
            s = dev.createRfcommSocketToServiceRecord(SPP_UUID);
            s.connect();
        } catch (IOException | SecurityException e) {
            why = e.getMessage();
            safeClose(s);
            s = null;
        }
        // 2) Insecure SPP socket.
        if (s == null) {
            try {
                s = dev.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                s.connect();
            } catch (IOException | SecurityException e) {
                why = e.getMessage();
                safeClose(s);
                s = null;
            }
        }
        // 3) Fixed RFCOMM channel 1 (fix for some HC-05 clones that hide the SDP record).
        if (s == null) {
            try {
                Method m = dev.getClass().getMethod("createRfcommSocket", int.class);
                s = (BluetoothSocket) m.invoke(dev, 1);
                if (s != null) s.connect();
            } catch (Exception e) {
                why = e.getMessage();
                safeClose(s);
                s = null;
            }
        }
        if (s == null) {
            emit(event("failed").putQuiet("message",
                    "Couldn't connect. Is the robot on and in range? (" + (why == null ? "no reply" : why) + ")"));
            return;
        }
        String name;
        try {
            name = dev.getName();
        } catch (SecurityException e) {
            name = null;
        }
        connectedName = name == null ? address : name;
        try {
            socket = s;
            out = s.getOutputStream();
            startReader(s);
        } catch (IOException e) {
            closeSocket();
            emit(event("failed").putQuiet("message", "Connected but the link dropped at once."));
            return;
        }
        emit(event("connected").putQuiet("name", connectedName).putQuiet("address", address));
    }

    private void startReader(final BluetoothSocket s) throws IOException {
        final InputStream in = s.getInputStream();
        Thread t = new Thread(() -> {
            byte[] buf = new byte[256];
            StringBuilder line = new StringBuilder();
            try {
                while (true) {
                    int n = in.read(buf);
                    if (n < 0) break;
                    for (int i = 0; i < n; i++) {
                        char c = (char) (buf[i] & 0xFF);
                        if (c == '\n') {
                            String l = line.toString().trim();
                            line.setLength(0);
                            if (!l.isEmpty()) emit(event("line").putQuiet("text", l));
                        } else if (c != '\r') {
                            line.append(c);
                            if (line.length() > 300) {
                                emit(event("line").putQuiet("text", line.toString()));
                                line.setLength(0);
                            }
                        }
                    }
                }
            } catch (IOException ignored) {
            }
            if (!closing && socket == s) {
                closeSocket();
                emit(event("disconnected").putQuiet("reason", "lost"));
            }
        }, "bt-reader");
        t.setDaemon(true);
        t.start();
    }

    private void writeAsync(final String text) {
        io.execute(() -> {
            OutputStream o = out;
            if (o == null) return;
            try {
                o.write(text.getBytes(StandardCharsets.US_ASCII));
                o.flush();
            } catch (IOException e) {
                if (!closing) {
                    closeSocket();
                    emit(event("disconnected").putQuiet("reason", "lost"));
                }
            }
        });
    }

    private void closeSocket() {
        closing = true;
        BluetoothSocket s = socket;
        socket = null;
        out = null;
        safeClose(s);
    }

    private static void safeClose(BluetoothSocket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (IOException ignored) {
        }
    }

    // ------------------------------------------------------------------ native -> JS

    private static Ev event(String type) {
        return new Ev(type);
    }

    private void emit(final Ev ev) {
        final String js = "window.__native && window.__native(" + ev.o.toString() + ")";
        ui.post(() -> {
            if (web != null) web.evaluateJavascript(js, null);
        });
    }

    /** Small JSON helper that never throws. */
    private static final class Ev {
        final JSONObject o = new JSONObject();

        Ev(String type) {
            putQuiet("type", type);
        }

        Ev putQuiet(String k, Object v) {
            try {
                o.put(k, v);
            } catch (JSONException ignored) {
            }
            return this;
        }
    }

    // ------------------------------------------------------------------ JS -> native

    private final class Bridge {
        @JavascriptInterface
        public boolean isNative() {
            return true;
        }

        @JavascriptInterface
        public String state() {
            JSONObject o = new JSONObject();
            try {
                o.put("hasBluetooth", adapter != null);
                o.put("permission", hasConnectPermission());
                o.put("enabled", adapter != null && adapter.isEnabled());
                o.put("connected", socket != null);
                o.put("name", connectedName);
            } catch (JSONException ignored) {
            }
            return o.toString();
        }

        /** Async: replies with {type:'ready'} or {type:'error'}. */
        @JavascriptInterface
        public void prepare() {
            ui.post(MainActivity.this::prepare);
        }

        @JavascriptInterface
        public String paired() {
            return pairedDevices().toString();
        }

        /** Async: replies with status/connecting, then connected or failed. */
        @JavascriptInterface
        public void connect(final String address) {
            io.execute(() -> doConnect(address));
        }

        @JavascriptInterface
        public void disconnect() {
            closeSocket();
        }

        @JavascriptInterface
        public void send(String text) {
            if (text != null && !text.isEmpty()) writeAsync(text);
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v == null || !v.hasVibrator()) return;
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createOneShot(Math.max(1, Math.min(ms, 400)), VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(Math.max(1, Math.min(ms, 400)));
                }
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void openBluetoothSettings() {
            ui.post(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
                } catch (Exception ignored) {
                }
            });
        }
    }
}
