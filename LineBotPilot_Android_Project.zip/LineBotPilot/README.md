# LineBot Pilot (Android)

Neon remote-control app for the Arduino Nano line-following robot with an **HC-05**
Bluetooth module. Native Android app (Java) with a WebView interface and a direct
classic-Bluetooth (SPP / RFCOMM) link to the HC-05.

- Android 6.0 or newer, phone with Bluetooth
- Works with HC-05 and HC-06 modules (SPP UUID 00001101-0000-1000-8000-00805F9B34FB)
- Matches `arduino/line_follower_robot.ino`: 9600 baud, SoftwareSerial on D2 (RX) / D3 (TX)

## Build the APK

### Option 1: GitHub (no install)
1. Create a new GitHub repository and upload everything in this folder
   (keep the `.github` folder; it holds the build script).
2. Open the **Actions** tab. The **Build APK** job runs on every upload
   (or press **Run workflow**).
3. When it turns green, open the run and download **LineBotPilot-apk**.
   Unzip it to get `app-release.apk`.

### Option 2: Android Studio
1. Install Android Studio, then **File > Open** and choose this folder.
2. Wait for "Gradle sync" to finish (it downloads what it needs the first time).
3. **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. Click **locate** in the pop-up: `app/build/outputs/apk/debug/app-debug.apk`.

## Install on the phone
Copy the APK to the phone and open it. Allow **Install unknown apps** for your
file manager or browser when Android asks.

## Use
1. Power the robot. Pair **HC-05** once in the phone's Bluetooth settings (PIN 1234 or 0000).
2. Open **LineBot Pilot** and tap **Connect**. Allow **Nearby devices** if asked.
3. Choose **HC-05**. The HC-05 LED changes from fast blinking to a slow double blink.

## Commands sent to the robot
| Control | Sends |
|---|---|
| Joystick (8 directions) | F B L R G I H J, and S when released |
| MANUAL / AUTO | M / A |
| STOP | X |
| Speed slider | 0-9, Q = max |
| Auto speed - / + | - / + |
| Sonar (every 0.45 s) | D |
| On connect | S, current speed, ? |

Replies the app understands: `Mode: AUTO/MANUAL`, `Auto speed: N`, `Distance: N cm`,
`Obstacle detected`, `Back on line`, `Path clear`, `Line not found`, `STOP`.
